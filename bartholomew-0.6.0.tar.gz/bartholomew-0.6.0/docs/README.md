# Bartholomew documentation website

## Running locally with Spin

To build and run the Bartholomew documentation website:

1. Install and configure [Spin](https://spin.fermyon.dev).

2. Run the following `npm` commands:

```
$ npm install
$ npm run spin
```

3. View documentation website at http://localhost:3000
